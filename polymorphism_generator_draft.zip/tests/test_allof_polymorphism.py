"""Regression coverage for implicit discriminator families built using allOf."""

import pytest

from pydantic_openapi_generator.language_converters.python.model_generator import generate_models
from pydantic_openapi_generator.parsers import parse_openapi_3_0, parse_openapi_3_1


@pytest.mark.parametrize("version", ["3.0.3", "3.1.1"])
def test_implicit_allof_discriminator_generates_typed_variants(version):
    parser = parse_openapi_3_0 if version.startswith("3.0") else parse_openapi_3_1
    spec = parser({
        "openapi": version,
        "info": {"title": "polymorphism", "version": "1"},
        "paths": {},
        "components": {"schemas": {
            "Party": {"type": "object", "discriminator": {"propertyName": "party_type"},
                      "required": ["party_type"], "properties": {"party_type": {"type": "string"}}},
            "Person": {"allOf": [{"$ref": "#/components/schemas/Party"},
                                 {"type": "object", "properties": {"person_name": {"type": "string"}}}]},
            "Driver": {"allOf": [{"$ref": "#/components/schemas/Person"},
                                 {"type": "object", "properties": {"licence": {"type": "string"}}}]},
            "Claim": {"type": "object", "properties": {
                "insured": {"$ref": "#/components/schemas/Party"},
                "related": {"type": "array", "items": {"$ref": "#/components/schemas/Party"}},
            }},
        }},
    })
    generated = {m.file_name: m for m in generate_models(spec.components)}
    assert "PartyVariant" in generated
    assert "Union[Party, Person, Driver]" in generated["PartyVariant"].content
    assert 'Literal[\'Person\']' in generated["Person"].content
    assert 'Literal[\'Driver\']' in generated["Driver"].content
    props = {p.name: p for p in generated["Claim"].properties}
    assert props["insured"].type.converted_type == "Optional[PartyVariant]"
    assert "PartyVariant" in props["related"].type.converted_type
