# Polymorphic allOf generator patch (draft)

This patch extends model generation to discover transitive `allOf` descendants of schemas with a discriminator, generates `Literal` discriminator values and a reusable `BaseVariant` discriminated union alias, and rewrites references (including array items) to use the alias.

**Verification status:** Syntax compilation succeeded. Integration tests could not be run in this environment because the `openapi_pydantic` and generator dependencies are not installed. The supplied pasted repository also omits the packaged Jinja templates, so alias template output and runtime imports need to be checked in the real checkout. This is a draft for review, not a production-validated patch.

**Follow-up:** Run the new tests, then an end-to-end Claims fixture, and review forward-reference import handling and collisions with existing explicit `oneOf` unions. Ensure the generator does not overwrite any pre-existing schema named `PartyVariant`, etc.
